<?php
// ============================================
// Admin - Settings
// ============================================

require_once 'includes/functions.php';

if (!isAdminLoggedIn()) {
    redirectAdmin('index.php');
}

// Get platform stats
$stats = getPlatformStats();

$page_title = 'Settings - Admin';
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main class="admin-main">
    <div class="admin-page-header">
        <h1>Settings</h1>
        <p>Platform settings and configuration</p>
    </div>

    <div class="admin-settings">
        <div class="settings-card">
            <h3>Platform Overview</h3>
            <div class="settings-grid">
                <div class="settings-item">
                    <span class="settings-label">Total Users</span>
                    <span class="settings-value"><?php echo $stats['total_users']; ?></span>
                </div>
                <div class="settings-item">
                    <span class="settings-label">Total Jobs</span>
                    <span class="settings-value"><?php echo $stats['total_jobs']; ?></span>
                </div>
                <div class="settings-item">
                    <span class="settings-label">Total Applications</span>
                    <span class="settings-value"><?php echo $stats['total_applications']; ?></span>
                </div>
                <div class="settings-item">
                    <span class="settings-label">Total Payments</span>
                    <span class="settings-value">KSh <?php echo number_format($stats['total_amount'], 2); ?></span>
                </div>
            </div>
        </div>

        <div class="settings-card">
            <h3>Coming Soon</h3>
            <div class="settings-list">
                <p>🔧 Site name and branding settings</p>
                <p>📧 Email configuration</p>
                <p>💳 Payment settings</p>
                <p>🔐 User management permissions</p>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>